module.exports = function(optionS) {
  const { join } = require("path");
  const json2xls = require("json2xls");
  const fs = require("fs");
  const pathNormalizer = file => join(__dirname, file);

  let options = {
    jsonFolder: "jsonData",
    fileList: "7SZDMW07016.json",
    outputJson: "output.json",
    outputLog: "output.txt",
    outputExcel: "output.xlsx"
  };

  if (optionS != null || typeof optionS != "undefined") {
    options = { ...options, ...optionS };
  }

  let { BlastJSON: fileList } = JSON.parse(
    fs.readFileSync(
      pathNormalizer(options.jsonFolder + "/" + options.fileList),
      "utf8"
    )
  );

  fileList = fileList.map(name => name.File);

  let logs = "";
  const results = [];
  for (let i = 0; i < fileList.length; i++) {
    const info = {};

    logs += fileList[i];
    const {
      BlastOutput2: {
        report: {
          results: { search: json }
        }
      }
    } = JSON.parse(
      fs.readFileSync(
        pathNormalizer(options.jsonFolder + "/" + fileList[i]),
        "utf8"
      )
    );

    info.fileName = fileList[i];
    info.qId = json.query_id;
    info.qTitle = json.query_title;

    info.hitId = null;
    info.hitTitle = null;
    if (json.hits.length > 0) {
      info.hitId = json.hits[0].description[0].id.split("|")[1];
      info.hitTitle = json.hits[0].description[0].title;
      logs += " => MATCHED\n";
    } else {
      const isDuplicated = results.find(query => query.qId == json.query_id);
      if (isDuplicated) {
        info.hitId = isDuplicated.hitId;
        info.hitTitle = isDuplicated.hitTitle;
        logs += " => MATCHED (DUPLICATED)\n";
      } else logs += " => NOT MATCHED\n";
    }

    results.push(info);
  }

  fs.writeFileSync(
    pathNormalizer(options.outputJson),
    JSON.stringify(results, null, 1),
    "utf8"
  );

  fs.writeFileSync(pathNormalizer(options.outputLog), logs, "utf8");

  const xls = json2xls(results);

  fs.writeFileSync(pathNormalizer(options.outputExcel), xls, "binary");
};
