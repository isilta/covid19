const blastFormatter = require("./blast");

blastFormatter({
  jsonFolder: "jsonData",
  fileList: "7SZDMW07016.json",
  outputJson: "output.json",
  outputLog: "output.txt",
  outputExcel: "output.xlsx"
});
